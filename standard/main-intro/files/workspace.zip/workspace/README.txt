Recover the note inside the hidden audit directory.
